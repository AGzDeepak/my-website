import React from 'react';

export default function About() {
  return (
    <section id="about" className="py-20 px-6 text-center">
      <h2 className="text-3xl font-bold mb-4">About Me</h2>
      <p className="max-w-2xl mx-auto text-lg text-gray-300">
        I am a versatile designer & developer passionate about building modern, responsive, and attractive websites. 
        This is a sample template using React, Tailwind CSS, and Framer Motion.
      </p>
    </section>
  );
}
