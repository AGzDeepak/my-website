import React from 'react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 px-6 bg-gray-800 text-center">
      <h2 className="text-3xl font-bold mb-6">Contact Me</h2>
      <form className="max-w-xl mx-auto grid gap-4">
        <input type="text" placeholder="Your Name" className="p-3 rounded-lg bg-gray-900 border border-gray-700 text-white" />
        <input type="email" placeholder="Your Email" className="p-3 rounded-lg bg-gray-900 border border-gray-700 text-white" />
        <textarea placeholder="Your Message" rows="5" className="p-3 rounded-lg bg-gray-900 border border-gray-700 text-white"></textarea>
        <button type="submit" className="px-6 py-3 bg-indigo-600 rounded-full font-medium shadow-lg hover:scale-105 transition">
          Send Message
        </button>
      </form>
    </section>
  );
}
