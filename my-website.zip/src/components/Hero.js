import React from 'react';
import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center bg-gradient-to-b from-gray-900 to-black">
      <motion.h1 initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1 }} className="text-5xl font-bold mb-4">
        Welcome to My Website
      </motion.h1>
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5, duration: 1 }} className="text-xl mb-6">
        A modern and versatile design
      </motion.p>
      <motion.a whileHover={{ scale: 1.1 }} href="#about" className="px-6 py-3 bg-indigo-600 rounded-full text-white font-medium shadow-lg">
        Explore More
      </motion.a>
    </section>
  );
}
