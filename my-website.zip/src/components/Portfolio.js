import React from 'react';

export default function Portfolio() {
  const projects = [
    { title: 'Project One', img: 'https://via.placeholder.com/400x250' },
    { title: 'Project Two', img: 'https://via.placeholder.com/400x250' },
    { title: 'Project Three', img: 'https://via.placeholder.com/400x250' },
  ];
  return (
    <section id="portfolio" className="py-20 px-6">
      <h2 className="text-3xl font-bold mb-10 text-center">Portfolio</h2>
      <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {projects.map((p, i) => (
          <div key={i} className="bg-gray-800 rounded-2xl overflow-hidden shadow-lg">
            <img src={p.img} alt={p.title} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-xl font-semibold">{p.title}</h3>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
