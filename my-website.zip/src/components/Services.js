import React from 'react';
import { Code, Palette, Smartphone } from 'lucide-react';

export default function Services() {
  const services = [
    { icon: <Code size={32} />, title: 'Web Development', desc: 'Modern and scalable websites.' },
    { icon: <Palette size={32} />, title: 'UI/UX Design', desc: 'Attractive and user-friendly designs.' },
    { icon: <Smartphone size={32} />, title: 'Responsive Design', desc: 'Optimized for all devices.' },
  ];
  return (
    <section id="services" className="py-20 px-6 bg-gray-800">
      <h2 className="text-3xl font-bold mb-10 text-center">Services</h2>
      <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        {services.map((s, i) => (
          <div key={i} className="p-6 bg-gray-900 rounded-2xl shadow-lg text-center hover:scale-105 transform transition">
            <div className="mb-4 flex justify-center text-indigo-400">{s.icon}</div>
            <h3 className="text-xl font-semibold mb-2">{s.title}</h3>
            <p className="text-gray-400">{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
